package Inicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioTrdApplicationTests {

	@Test
	void contextLoads() {
	}

}
