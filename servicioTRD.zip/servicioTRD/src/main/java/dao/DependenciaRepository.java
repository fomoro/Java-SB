package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface DependenciaRepository extends JpaRepository<Dependencia, Integer> {
}