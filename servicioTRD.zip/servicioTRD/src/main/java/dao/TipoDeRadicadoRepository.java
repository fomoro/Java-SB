package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface TipoDeRadicadoRepository extends JpaRepository<TipoDeRadicado, Integer> {
}
