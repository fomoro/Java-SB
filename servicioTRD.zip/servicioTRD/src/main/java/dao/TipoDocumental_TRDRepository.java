package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface TipoDocumental_TRDRepository extends JpaRepository<TipoDocumental_TRD, Integer> {
}
