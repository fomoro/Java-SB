package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface FondoRepository extends JpaRepository<Fondo, Integer> {
}