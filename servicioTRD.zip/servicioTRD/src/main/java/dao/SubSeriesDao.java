package dao;

import java.util.List;

import model.*;

public interface SubSeriesDao {

	SubSerie recuperarSubSerie(Long id);
	void agregarSubSerie(SubSerie subSerie);
	List<SubSerie> devolverSubSeries();
	void actualizarSubSerie(SubSerie subSerie);
	void eliminarSubSerie(Long idSubSerie);
}
