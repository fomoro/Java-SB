package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface SoporteDocumentalRepository extends JpaRepository<SoporteDocumental, Integer> {
}
