package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface DetalleSoporteDocumentalRepository extends JpaRepository<DetalleSoporteDocumental, Integer> {
}
