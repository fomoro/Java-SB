package dao;

import org.springframework.data.jpa.repository.*;
import model.*;

public interface TipoDocumentalRepository extends JpaRepository<TipoDocumental, Integer> {
}
