package dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.*;

@Repository
public class SubSeriesDaoImpl implements SubSeriesDao {

	@Autowired
	SubSeriesJpaSpring SubSerie;
	
	@Override
	public SubSerie recuperarSubSerie(Long id) {	
		return SubSerie.findById(id).orElse(null);
	}
	
	@Override
	public void agregarSubSerie(SubSerie subSerie) {
		SubSerie.save(subSerie);
	}

	@Override
	public List<SubSerie> devolverSubSeries() {
		return SubSerie.findAll();
	}
	
	@Override
	public void actualizarSubSerie(SubSerie subSerie) {
		SubSerie.save(subSerie);
	}
	
	@Override
	public void eliminarSubSerie(Long idSubSerie) {
		SubSerie.deleteById(idSubSerie);
		
	}
}
