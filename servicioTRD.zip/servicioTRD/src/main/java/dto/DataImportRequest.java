package dto;

public class DataImportRequest {
    private FondoDTO[] fondos;
    private DependenciaDTO[] dependencias;
    private SoporteDocumentalDTO[] soportesDocumentales;
    private DetalleSoporteDocumentalDTO[] detallesSoporteDocumental;
    private SerieDTO[] series;
    private TRDDTO[] trds;
    private TipoDeRadicadoDTO[] tiposDeRadicado;
    private TipoDocumentalDTO[] tiposDocumentales;
    private TipoDocumental_TRDDTO[] tiposDocumentalTRD;
    
	public FondoDTO[] getFondos() {
		return fondos;
	}
	public void setFondos(FondoDTO[] fondos) {
		this.fondos = fondos;
	}
	public DependenciaDTO[] getDependencias() {
		return dependencias;
	}
	public void setDependencias(DependenciaDTO[] dependencias) {
		this.dependencias = dependencias;
	}
	public SoporteDocumentalDTO[] getSoportesDocumentales() {
		return soportesDocumentales;
	}
	public void setSoportesDocumentales(SoporteDocumentalDTO[] soportesDocumentales) {
		this.soportesDocumentales = soportesDocumentales;
	}
	public DetalleSoporteDocumentalDTO[] getDetallesSoporteDocumental() {
		return detallesSoporteDocumental;
	}
	public void setDetallesSoporteDocumental(DetalleSoporteDocumentalDTO[] detallesSoporteDocumental) {
		this.detallesSoporteDocumental = detallesSoporteDocumental;
	}
	public SerieDTO[] getSeries() {
		return series;
	}
	public void setSeries(SerieDTO[] series) {
		this.series = series;
	}
	public TRDDTO[] getTrds() {
		return trds;
	}
	public void setTrds(TRDDTO[] trds) {
		this.trds = trds;
	}
	public TipoDeRadicadoDTO[] getTiposDeRadicado() {
		return tiposDeRadicado;
	}
	public void setTiposDeRadicado(TipoDeRadicadoDTO[] tiposDeRadicado) {
		this.tiposDeRadicado = tiposDeRadicado;
	}
	public TipoDocumentalDTO[] getTiposDocumentales() {
		return tiposDocumentales;
	}
	public void setTiposDocumentales(TipoDocumentalDTO[] tiposDocumentales) {
		this.tiposDocumentales = tiposDocumentales;
	}
	public TipoDocumental_TRDDTO[] getTiposDocumentalTRD() {
		return tiposDocumentalTRD;
	}
	public void setTiposDocumentalTRD(TipoDocumental_TRDDTO[] tiposDocumentalTRD) {
		this.tiposDocumentalTRD = tiposDocumentalTRD;
	}
    
    
}
