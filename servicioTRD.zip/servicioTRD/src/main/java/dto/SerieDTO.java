package dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SerieDTO {
    private int idSerieSubserie;
    private SerieDTO padre;
    private String descripcion;
    private Date fechaVigenciaInicial;
    private Date fechaVigenciaFinal;
    private int ct;
    private int e;
    private int mt;
    private int s;
    private int tiempoArchivoGestion;
    private int tiempoArchivoCentral;
    private String observacion;
}