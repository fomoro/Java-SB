package dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DependenciaDTO {
    private int idDependencia;
    private String nombre;
    private String direccion;
    private String sigla;
    private int estado;
    private DependenciaDTO padre;
    private FondoDTO fondo;
}
