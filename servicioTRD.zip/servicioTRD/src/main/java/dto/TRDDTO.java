package dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TRDDTO {
    private int idTrd;
    private SerieDTO serieSubserie;
    private String observacion;
    private int estado;
    private DependenciaDTO dependencia;
}