package dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TipoDocumental_TRDDTO {
    private TipoDocumentalDTO tipoDocumental;
    private TRDDTO trd;
    private DetalleSoporteDocumentalDTO detalleSoporteDocumental;
}