package mapper;

import org.modelmapper.ModelMapper;
import java.util.List;
import java.util.stream.Collectors;
import dto.*;
import model.*;

public class Mapper {
    private static final ModelMapper modelMapper = new ModelMapper();

    public static FondoDTO convertToFondoDTO(Fondo fondo) {
        return modelMapper.map(fondo, FondoDTO.class);
    }

    public static Fondo convertToFondo(FondoDTO fondoDTO) {
        return modelMapper.map(fondoDTO, Fondo.class);
    }
    
    public static List<FondoDTO> convertToFondoDTOList(List<Fondo> fondos) {
        return fondos.stream()
                .map(fondo -> modelMapper.map(fondo, FondoDTO.class))
                .collect(Collectors.toList());
    }

    public static DependenciaDTO convertToDependenciaDTO(Dependencia dependencia) {
        return modelMapper.map(dependencia, DependenciaDTO.class);
    }

    public static Dependencia convertToDependencia(DependenciaDTO dependenciaDTO) {
        return modelMapper.map(dependenciaDTO, Dependencia.class);
    }
    
    public static List<DependenciaDTO> convertToDependenciaDTOList(List<Dependencia> dependencias) {
        return dependencias.stream()
                .map(dependencia -> modelMapper.map(dependencia, DependenciaDTO.class))
                .collect(Collectors.toList());
    }
    
    public static SoporteDocumentalDTO convertToSoporteDocumentalDTO(SoporteDocumental soporteDocumental) {
        return modelMapper.map(soporteDocumental, SoporteDocumentalDTO.class);
    }

    public static SoporteDocumental convertToSoporteDocumental(SoporteDocumentalDTO soporteDocumentalDTO) {
        return modelMapper.map(soporteDocumentalDTO, SoporteDocumental.class);
    }
    
    public static List<SoporteDocumentalDTO> convertToSoporteDocumentalDTOList(List<SoporteDocumental> soporteDocumentalList) {
        return soporteDocumentalList.stream()
                .map(sd -> modelMapper.map(sd, SoporteDocumentalDTO.class))
                .collect(Collectors.toList());
    }

    public static DetalleSoporteDocumentalDTO convertToDetalleSoporteDocumentalDTO(DetalleSoporteDocumental detalleSoporteDocumental) {
        return modelMapper.map(detalleSoporteDocumental, DetalleSoporteDocumentalDTO.class);
    }

    public static DetalleSoporteDocumental convertToDetalleSoporteDocumental(DetalleSoporteDocumentalDTO detalleSoporteDocumentalDTO) {
        return modelMapper.map(detalleSoporteDocumentalDTO, DetalleSoporteDocumental.class);
    }
    
    public static List<DetalleSoporteDocumentalDTO> convertToDetalleSoporteDocumentalDTOList(List<DetalleSoporteDocumental> detallesSoporteDocumental) {
        return detallesSoporteDocumental.stream()
                .map(dsd -> modelMapper.map(dsd, DetalleSoporteDocumentalDTO.class))
                .collect(Collectors.toList());
    }

    public static SerieDTO convertToSerieDTO(Serie serie) {
        return modelMapper.map(serie, SerieDTO.class);
    }

    public static Serie convertToSerie(SerieDTO serieDTO) {
        return modelMapper.map(serieDTO, Serie.class);
    }

    public static List<SerieDTO> convertToSerieDTOList(List<Serie> series) {
        return series.stream()
                .map(serie -> modelMapper.map(serie, SerieDTO.class))
                .collect(Collectors.toList());
    }
    
    public static TRDDTO convertToTRDDTO(TRD trd) {
        return modelMapper.map(trd, TRDDTO.class);
    }

    public static TRD convertToTRD(TRDDTO trdDTO) {
        return modelMapper.map(trdDTO, TRD.class);
    }

    public static TipoDeRadicadoDTO convertToTipoDeRadicadoDTO(TipoDeRadicado tipoDeRadicado) {
        return modelMapper.map(tipoDeRadicado, TipoDeRadicadoDTO.class);
    }

    public static TipoDeRadicado convertToTipoDeRadicado(TipoDeRadicadoDTO tipoDeRadicadoDTO) {
        return modelMapper.map(tipoDeRadicadoDTO, TipoDeRadicado.class);
    }
    
    public static List<TipoDeRadicadoDTO> convertToTipoDeRadicadoDTOList(List<TipoDeRadicado> tiposDeRadicado) {
        return tiposDeRadicado.stream()
                .map(tipoDeRadicado -> modelMapper.map(tipoDeRadicado, TipoDeRadicadoDTO.class))
                .collect(Collectors.toList());
    }

    public static TipoDocumentalDTO convertToTipoDocumentalDTO(TipoDocumental tipoDocumental) {
        return modelMapper.map(tipoDocumental, TipoDocumentalDTO.class);
    }

    public static TipoDocumental convertToTipoDocumental(TipoDocumentalDTO tipoDocumentalDTO) {
        return modelMapper.map(tipoDocumentalDTO, TipoDocumental.class);
    }

    public static List<TipoDocumentalDTO> convertToTipoDocumentalDTOList(List<TipoDocumental> tipoDocumentalList) {
        return tipoDocumentalList.stream()
                .map(td -> modelMapper.map(td, TipoDocumentalDTO.class))
                .collect(Collectors.toList());
    }
    
    public static TipoDocumental_TRDDTO convertToTipoDocumental_TRDDTO(TipoDocumental_TRD tipoDocumental_TRD) {
        return modelMapper.map(tipoDocumental_TRD, TipoDocumental_TRDDTO.class);
    }

    public static TipoDocumental_TRD convertToTipoDocumental_TRD(TipoDocumental_TRDDTO tipoDocumental_TRDDTO) {
        return modelMapper.map(tipoDocumental_TRDDTO, TipoDocumental_TRD.class);
    }
    
    public static List<TipoDocumental_TRDDTO> convertToTipoDocumental_TRDDTOList(List<TipoDocumental_TRD> tipoDocumental_TRDList) {
        return tipoDocumental_TRDList.stream()
                .map(tdt -> modelMapper.map(tdt, TipoDocumental_TRDDTO.class))
                .collect(Collectors.toList());
    }
}