package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class TipoDocumental_TRDServiceImpl implements TipoDocumental_TRDService {
    private final TipoDocumental_TRDRepository tipoDocumental_TRDRepository;

    @Autowired
    public TipoDocumental_TRDServiceImpl(TipoDocumental_TRDRepository tipoDocumental_TRDRepository) {
        this.tipoDocumental_TRDRepository = tipoDocumental_TRDRepository;
    }

    @Override
    public TipoDocumental_TRDDTO getTipoDocumental_TRDById(int id) {
        TipoDocumental_TRD tipoDocumental_TRD = tipoDocumental_TRDRepository.findById(id).orElseThrow();                
        return Mapper.convertToTipoDocumental_TRDDTO(tipoDocumental_TRD);
    }

    @Override
    public List<TipoDocumental_TRDDTO> getAllTiposDocumentales_TRD() {
        List<TipoDocumental_TRD> tipoDocumental_TRDList = tipoDocumental_TRDRepository.findAll();
        return Mapper.convertToTipoDocumental_TRDDTOList(tipoDocumental_TRDList);
    }

    @Override
    public TipoDocumental_TRDDTO createTipoDocumental_TRD(TipoDocumental_TRDDTO tipoDocumental_TRDDTO) {
        TipoDocumental_TRD tipoDocumental_TRD = Mapper.convertToTipoDocumental_TRD(tipoDocumental_TRDDTO);
        TipoDocumental_TRD savedTipoDocumental_TRD = tipoDocumental_TRDRepository.save(tipoDocumental_TRD);
        return Mapper.convertToTipoDocumental_TRDDTO(savedTipoDocumental_TRD);
    }

    @Override
    public TipoDocumental_TRDDTO updateTipoDocumental_TRD(int id, TipoDocumental_TRDDTO tipoDocumental_TRDDTO) {
        TipoDocumental_TRD existingTipoDocumental_TRD = tipoDocumental_TRDRepository.findById(id).orElseThrow();

        //existingTipoDocumental_TRD.setIdTipoDocumental(tipoDocumental_TRDDTO.getIdTipoDocumental());
        //existingTipoDocumental_TRD.setIdTRD(tipoDocumental_TRDDTO.getIdTRD());

        TipoDocumental_TRD updatedTipoDocumental_TRD = tipoDocumental_TRDRepository.save(existingTipoDocumental_TRD);
        return Mapper.convertToTipoDocumental_TRDDTO(updatedTipoDocumental_TRD);
    }

    @Override
    public void deleteTipoDocumental_TRD(int id) {
        TipoDocumental_TRD existingTipoDocumental_TRD = tipoDocumental_TRDRepository.findById(id).orElseThrow();
        tipoDocumental_TRDRepository.delete(existingTipoDocumental_TRD);
    }
}
