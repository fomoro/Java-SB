package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class SerieServiceImpl implements SerieService {
    private final SerieRepository serieRepository;

    @Autowired
    public SerieServiceImpl(SerieRepository serieRepository) {
        this.serieRepository = serieRepository;
    }

    @Override
    public SerieDTO getSerieById(int id) {
        Serie serie = serieRepository.findById(id).orElseThrow();
        return Mapper.convertToSerieDTO(serie);
    }

    @Override
    public List<SerieDTO> getAllSeries() {
        List<Serie> series = serieRepository.findAll();
        return Mapper.convertToSerieDTOList(series);
    }

    @Override
    public SerieDTO createSerie(SerieDTO serieDTO) {
        Serie serie = Mapper.convertToSerie(serieDTO);
        Serie savedSerie = serieRepository.save(serie);
        return Mapper.convertToSerieDTO(savedSerie);
    }

    @Override
    public SerieDTO updateSerie(int id, SerieDTO serieDTO) {
        Serie existingSerie = serieRepository.findById(id).orElseThrow();
        /*
        existingSerie.setDescripcion(serieDTO.getDescripcion());
        existingSerie.setIdPadre(serieDTO.getIdPadre());
        existingSerie.setFechaVigenciaInicial(serieDTO.getFechaVigenciaInicial());
        existingSerie.setFechaVigenciaFinal(serieDTO.getFechaVigenciaFinal());
        existingSerie.setCT(serieDTO.getCT());
        existingSerie.setE(serieDTO.getE());
        existingSerie.setMT(serieDTO.getMT());
        existingSerie.setS(serieDTO.getS());
        existingSerie.setTiempoArchivoGestion(serieDTO.getTiempoArchivoGestion());
        existingSerie.setTiempoArchivoCentral(serieDTO.getTiempoArchivoCentral());
        existingSerie.setObservacion(serieDTO.getObservacion());
        */
        Serie updatedSerie = serieRepository.save(existingSerie);
        return Mapper.convertToSerieDTO(updatedSerie);
    }

    @Override
    public void deleteSerie(int id) {
        Serie existingSerie = serieRepository.findById(id).orElseThrow();
        serieRepository.delete(existingSerie);
    }
}
