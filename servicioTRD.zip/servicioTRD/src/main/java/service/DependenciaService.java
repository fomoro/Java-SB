package service;

import java.util.List;
import dto.*;

public interface DependenciaService {
    DependenciaDTO getDependenciaById(int id);
    List<DependenciaDTO> getAllDependencias();
    DependenciaDTO createDependencia(DependenciaDTO dependenciaDTO);
    DependenciaDTO updateDependencia(int id, DependenciaDTO dependenciaDTO);
    void deleteDependencia(int id);
}