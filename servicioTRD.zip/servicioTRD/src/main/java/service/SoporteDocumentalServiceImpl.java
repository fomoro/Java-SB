package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class SoporteDocumentalServiceImpl implements SoporteDocumentalService {
    private final SoporteDocumentalRepository soporteDocumentalRepository;

    @Autowired
    public SoporteDocumentalServiceImpl(SoporteDocumentalRepository soporteDocumentalRepository) {
        this.soporteDocumentalRepository = soporteDocumentalRepository;
    }

    @Override
    public SoporteDocumentalDTO getSoporteDocumentalById(int id) {
        SoporteDocumental soporteDocumental = soporteDocumentalRepository.findById(id).orElseThrow();                
        return Mapper.convertToSoporteDocumentalDTO(soporteDocumental);
    }

    @Override
    public List<SoporteDocumentalDTO> getAllSoporteDocumentales() {
        List<SoporteDocumental> soporteDocumentalList = soporteDocumentalRepository.findAll();
        return Mapper.convertToSoporteDocumentalDTOList(soporteDocumentalList);
    }

    @Override
    public SoporteDocumentalDTO createSoporteDocumental(SoporteDocumentalDTO soporteDocumentalDTO) {
        SoporteDocumental soporteDocumental = Mapper.convertToSoporteDocumental(soporteDocumentalDTO);
        SoporteDocumental savedSoporteDocumental = soporteDocumentalRepository.save(soporteDocumental);
        return Mapper.convertToSoporteDocumentalDTO(savedSoporteDocumental);
    }

    @Override
    public SoporteDocumentalDTO updateSoporteDocumental(int id, SoporteDocumentalDTO soporteDocumentalDTO) {
        SoporteDocumental existingSoporteDocumental = soporteDocumentalRepository.findById(id).orElseThrow();

        //existingSoporteDocumental.setDescripcion(soporteDocumentalDTO.getDescripcion());

        SoporteDocumental updatedSoporteDocumental = soporteDocumentalRepository.save(existingSoporteDocumental);
        return Mapper.convertToSoporteDocumentalDTO(updatedSoporteDocumental);
    }

    @Override
    public void deleteSoporteDocumental(int id) {
        SoporteDocumental existingSoporteDocumental = soporteDocumentalRepository.findById(id).orElseThrow();
        soporteDocumentalRepository.delete(existingSoporteDocumental);
    }
}
