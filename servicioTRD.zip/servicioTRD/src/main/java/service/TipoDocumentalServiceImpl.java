package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class TipoDocumentalServiceImpl implements TipoDocumentalService {
    private final TipoDocumentalRepository tipoDocumentalRepository;

    @Autowired
    public TipoDocumentalServiceImpl(TipoDocumentalRepository tipoDocumentalRepository) {
        this.tipoDocumentalRepository = tipoDocumentalRepository;
    }

    @Override
    public TipoDocumentalDTO getTipoDocumentalById(int id) {
        TipoDocumental tipoDocumental = tipoDocumentalRepository.findById(id).orElseThrow();                
        return Mapper.convertToTipoDocumentalDTO(tipoDocumental);
    }

    @Override
    public List<TipoDocumentalDTO> getAllTiposDocumentales() {
        List<TipoDocumental> tipoDocumentalList = tipoDocumentalRepository.findAll();
        return Mapper.convertToTipoDocumentalDTOList(tipoDocumentalList);
    }

    @Override
    public TipoDocumentalDTO createTipoDocumental(TipoDocumentalDTO tipoDocumentalDTO) {
        TipoDocumental tipoDocumental = Mapper.convertToTipoDocumental(tipoDocumentalDTO);
        TipoDocumental savedTipoDocumental = tipoDocumentalRepository.save(tipoDocumental);
        return Mapper.convertToTipoDocumentalDTO(savedTipoDocumental);
    }

    @Override
    public TipoDocumentalDTO updateTipoDocumental(int id, TipoDocumentalDTO tipoDocumentalDTO) {
        TipoDocumental existingTipoDocumental = tipoDocumentalRepository.findById(id).orElseThrow();

        //existingTipoDocumental.setTerminoTramite(tipoDocumentalDTO.getTerminoTramite());
        //existingTipoDocumental.setTipoDeRadicado(tipoDocumentalDTO.getTipoDeRadicado());
        //existingTipoDocumental.setDescripcion(tipoDocumentalDTO.getDescripcion());

        TipoDocumental updatedTipoDocumental = tipoDocumentalRepository.save(existingTipoDocumental);
        return Mapper.convertToTipoDocumentalDTO(updatedTipoDocumental);
    }

    @Override
    public void deleteTipoDocumental(int id) {
        TipoDocumental existingTipoDocumental = tipoDocumentalRepository.findById(id).orElseThrow();
        tipoDocumentalRepository.delete(existingTipoDocumental);
    }
}
