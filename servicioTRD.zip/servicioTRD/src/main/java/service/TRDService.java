package service;

import java.util.List;
import dto.*;

public interface TRDService {
    TRDDTO getTRDById(int id);
    List<TRDDTO> getAllTRDs();
    TRDDTO createTRD(TRDDTO trdDTO);
    TRDDTO updateTRD(int id, TRDDTO trdDTO);
    void deleteTRD(int id);
}
