package service;

import java.util.List;
import dto.*;

public interface DataImportService {
    String importDataJSON(DataImportRequest request);
    void importDataFromTXT();
}