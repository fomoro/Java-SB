package service;

import java.util.List;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;


@Service
public class DataImportServiceImpl implements DataImportService {

	private final FondoService fondoService;
	private final DependenciaService dependenciaService;
	private final SoporteDocumentalService soporteDocumentalService;
	private final DetalleSoporteDocumentalService detalleSoporteDocumentalService;
	private final SerieService serieService;
	private final TRDService trdService;
	private final TipoDeRadicadoService tipoDeRadicadoService;
	private final TipoDocumentalService tipoDocumentalService;
	private final TipoDocumental_TRDService tipoDocumentalTRDService;

	@Autowired
	public DataImportServiceImpl(FondoService fondoService, DependenciaService dependenciaService,
			SoporteDocumentalService soporteDocumentalService,
			DetalleSoporteDocumentalService detalleSoporteDocumentalService, SerieService serieService,
			TRDService trdService, TipoDeRadicadoService tipoDeRadicadoService,
			TipoDocumentalService tipoDocumentalService, TipoDocumental_TRDService tipoDocumentalTRDService) {
		this.fondoService = fondoService;
		this.dependenciaService = dependenciaService;
		this.soporteDocumentalService = soporteDocumentalService;
		this.detalleSoporteDocumentalService = detalleSoporteDocumentalService;
		this.serieService = serieService;
		this.trdService = trdService;
		this.tipoDeRadicadoService = tipoDeRadicadoService;
		this.tipoDocumentalService = tipoDocumentalService;
		this.tipoDocumentalTRDService = tipoDocumentalTRDService;
	}

	public String importDataJSON(DataImportRequest request) {
		FondoDTO[] fondos = request.getFondos();
		for (FondoDTO fondoDTO : fondos) {
			fondoService.createFondo(fondoDTO);
		}

		DependenciaDTO[] dependencias = request.getDependencias();
		for (DependenciaDTO dependencia : dependencias) {
			dependenciaService.createDependencia(dependencia);
		}

		SoporteDocumentalDTO[] soportesDocumentales = request.getSoportesDocumentales();
		for (SoporteDocumentalDTO soporteDocumental : soportesDocumentales) {
			soporteDocumentalService.createSoporteDocumental(soporteDocumental);
		}

		DetalleSoporteDocumentalDTO[] detallesSoporteDocumental = request.getDetallesSoporteDocumental();
		for (DetalleSoporteDocumentalDTO detalleSoporteDocumental : detallesSoporteDocumental) {
			detalleSoporteDocumentalService.createDetalleSoporteDocumental(detalleSoporteDocumental);
		}

		SerieDTO[] series = request.getSeries();
		for (SerieDTO serie : series) {
			serieService.createSerie(serie);
		}

		TRDDTO[] trds = request.getTrds();
		for (TRDDTO trd : trds) {
			trdService.createTRD(trd);
		}

		TipoDeRadicadoDTO[] tiposDeRadicado = request.getTiposDeRadicado();
		for (TipoDeRadicadoDTO tipoDeRadicado : tiposDeRadicado) {
			tipoDeRadicadoService.createTipoDeRadicado(tipoDeRadicado);
		}

		TipoDocumentalDTO[] tiposDocumentales = request.getTiposDocumentales();
		for (TipoDocumentalDTO tipoDocumental : tiposDocumentales) {
			tipoDocumentalService.createTipoDocumental(tipoDocumental);
		}

		TipoDocumental_TRDDTO[] tiposDocumentalTRD = request.getTiposDocumentalTRD();
		for (TipoDocumental_TRDDTO tipoDocumentalTRD : tiposDocumentalTRD) {
			tipoDocumentalTRDService.createTipoDocumental_TRD(tipoDocumentalTRD);
		}

		return "Datos importados exitosamente";
	}
	
	public void importDataFromTXT() {
		String filename = "output.txt";
		Path filePath = Paths.get(filename);

		try (BufferedReader reader = Files.newBufferedReader(filePath)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] data = line.split("\t");

				if (data.length > 0) {
					String tableName = data[0];

					switch (tableName) {
					case "Fondo":
						importFondo(data);
						break;
					case "Dependencia":
						importDependencia(data);
						break;
					case "SoporteDocumental":
						importSoporteDocumental(data);
						break;

					default:
						// Tabla desconocida
						break;
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void importFondo(String[] data) {
		FondoDTO fondoDTO = new FondoDTO();
		//fondoDTO.setNombre(data[1]);
		//fondoDTO.setDescripcion(data[2]);
		fondoService.createFondo(fondoDTO);
	}

	private void importDependencia(String[] data) {
		DependenciaDTO dependenciaDTO = new DependenciaDTO();
		/*dependenciaDTO.setNombre(data[1]);
		dependenciaDTO.setDireccion(data[2]);
		dependenciaDTO.setSigla(data[3]);
		dependenciaDTO.setEstado(Integer.parseInt(data[4]));
		dependenciaDTO.setIdPadre(Integer.parseInt(data[5]));
		dependenciaDTO.setIdFondo(Integer.parseInt(data[6]));*/
		dependenciaService.createDependencia(dependenciaDTO);
	}

	private void importSoporteDocumental(String[] data) {
		SoporteDocumentalDTO soporteDocumentalDTO = new SoporteDocumentalDTO();
		//soporteDocumentalDTO.setDescripcion(data[1]);
		soporteDocumentalService.createSoporteDocumental(soporteDocumentalDTO);
	}

}
