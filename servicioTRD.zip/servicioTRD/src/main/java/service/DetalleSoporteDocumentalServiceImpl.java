package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;
import java.util.List;

@Service
public class DetalleSoporteDocumentalServiceImpl implements DetalleSoporteDocumentalService {
    private final DetalleSoporteDocumentalRepository detalleSoporteDocumentalRepository;

    @Autowired
    public DetalleSoporteDocumentalServiceImpl(DetalleSoporteDocumentalRepository detalleSoporteDocumentalRepository) {
        this.detalleSoporteDocumentalRepository = detalleSoporteDocumentalRepository;
    }

    @Override
    public DetalleSoporteDocumentalDTO getDetalleSoporteDocumentalById(int id) {
        DetalleSoporteDocumental detalleSoporteDocumental = detalleSoporteDocumentalRepository.findById(id).orElseThrow();
        return Mapper.convertToDetalleSoporteDocumentalDTO(detalleSoporteDocumental);
    }

    @Override
    public List<DetalleSoporteDocumentalDTO> getAllDetallesSoporteDocumentales() {
        List<DetalleSoporteDocumental> detallesSoporteDocumental = detalleSoporteDocumentalRepository.findAll();
        return Mapper.convertToDetalleSoporteDocumentalDTOList(detallesSoporteDocumental);
    }

    @Override
    public DetalleSoporteDocumentalDTO createDetalleSoporteDocumental(DetalleSoporteDocumentalDTO detalleSoporteDocumentalDTO) {
        DetalleSoporteDocumental detalleSoporteDocumental = Mapper.convertToDetalleSoporteDocumental(detalleSoporteDocumentalDTO);
        DetalleSoporteDocumental savedDetalleSoporteDocumental = detalleSoporteDocumentalRepository.save(detalleSoporteDocumental);
        return Mapper.convertToDetalleSoporteDocumentalDTO(savedDetalleSoporteDocumental);
    }

    @Override
    public DetalleSoporteDocumentalDTO updateDetalleSoporteDocumental(int id, DetalleSoporteDocumentalDTO detalleSoporteDocumentalDTO) {
        DetalleSoporteDocumental existingDetalleSoporteDocumental = detalleSoporteDocumentalRepository.findById(id).orElseThrow();

        //existingDetalleSoporteDocumental.setDescripcion(detalleSoporteDocumentalDTO.getDescripcion());

        DetalleSoporteDocumental updatedDetalleSoporteDocumental = detalleSoporteDocumentalRepository.save(existingDetalleSoporteDocumental);
        return Mapper.convertToDetalleSoporteDocumentalDTO(updatedDetalleSoporteDocumental);
    }

    @Override
    public void deleteDetalleSoporteDocumental(int id) {
        DetalleSoporteDocumental existingDetalleSoporteDocumental = detalleSoporteDocumentalRepository.findById(id).orElseThrow();
        detalleSoporteDocumentalRepository.delete(existingDetalleSoporteDocumental);
    }
}
