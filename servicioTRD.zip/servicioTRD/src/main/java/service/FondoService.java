package service;

import java.util.List;
import dto.*;

public interface FondoService {
    FondoDTO getFondoById(int id);
    List<FondoDTO> getAllFondos();
    FondoDTO createFondo(FondoDTO fondoDTO);
    FondoDTO updateFondo(int id, FondoDTO fondoDTO);
    void deleteFondo(int id);
}

