package service;

import java.util.List;
import dto.*;

public interface TipoDocumental_TRDService {
    TipoDocumental_TRDDTO getTipoDocumental_TRDById(int id);
    List<TipoDocumental_TRDDTO> getAllTiposDocumentales_TRD();
    TipoDocumental_TRDDTO createTipoDocumental_TRD(TipoDocumental_TRDDTO tipoDocumental_TRDDTO);
    TipoDocumental_TRDDTO updateTipoDocumental_TRD(int id, TipoDocumental_TRDDTO tipoDocumental_TRDDTO);
    void deleteTipoDocumental_TRD(int id);
}