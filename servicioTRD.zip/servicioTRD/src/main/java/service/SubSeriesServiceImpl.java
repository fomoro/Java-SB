package service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import model.*;

@Service
public class SubSeriesServiceImpl implements SubSeriesService {

	@Autowired
	SubSeriesDao dao;
	
	@Override
	public boolean agregarSubserie(SubSerie subSerie) {
		if(dao.recuperarSubSerie(subSerie.getIdSubSerie())==null) {
			dao.agregarSubSerie(subSerie);
			return true;
		}
		return false;
	}

	@Override
	public List<SubSerie> recuperarSubSeries() {
		return dao.devolverSubSeries();
	}

	@Override
	public void actualizarSubSerie(SubSerie subSerie) {	
		if(dao.recuperarSubSerie(subSerie.getIdSubSerie())!=null) {
			dao.actualizarSubSerie(subSerie);
		}
	}

	@Override
	public boolean eliminarSubserie(Long idSubSerie) {
		if(dao.recuperarSubSerie(idSubSerie)!=null) {
			dao.eliminarSubSerie(idSubSerie);
			return true;
		}
		return false;
	}

	@Override
	public SubSerie buscarSubserie(Long idSubSerie) {
		return dao.recuperarSubSerie(idSubSerie);
	}

}
