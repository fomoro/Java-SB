package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;
import java.util.List;

@Service
public class DependenciaServiceImpl implements DependenciaService {
    private final DependenciaRepository dependenciaRepository;

    @Autowired
    public DependenciaServiceImpl(DependenciaRepository dependenciaRepository) {
        this.dependenciaRepository = dependenciaRepository;
    }

    @Override
    public DependenciaDTO getDependenciaById(int id) {
        Dependencia dependencia = dependenciaRepository.findById(id).orElseThrow();
        return Mapper.convertToDependenciaDTO(dependencia);
    }

    @Override
    public List<DependenciaDTO> getAllDependencias() {
        List<Dependencia> dependencias = dependenciaRepository.findAll();
        return Mapper.convertToDependenciaDTOList(dependencias);
    }

    @Override
    public DependenciaDTO createDependencia(DependenciaDTO dependenciaDTO) {
        Dependencia dependencia = Mapper.convertToDependencia(dependenciaDTO);
        Dependencia savedDependencia = dependenciaRepository.save(dependencia);
        return Mapper.convertToDependenciaDTO(savedDependencia);
    }

    @Override
    public DependenciaDTO updateDependencia(int id, DependenciaDTO dependenciaDTO) {
        Dependencia existingDependencia = dependenciaRepository.findById(id).orElseThrow();

        /*existingDependencia.setNombre(dependenciaDTO.getNombre());
        existingDependencia.setDireccion(dependenciaDTO.getDireccion());
        existingDependencia.setSigla(dependenciaDTO.getSigla());
        existingDependencia.setEstado(dependenciaDTO.getEstado());
        existingDependencia.setIdPadre(dependenciaDTO.getIdPadre());
        existingDependencia.setIdFondo(dependenciaDTO.getIdFondo());*/

        Dependencia updatedDependencia = dependenciaRepository.save(existingDependencia);
        return Mapper.convertToDependenciaDTO(updatedDependencia);
    }

    @Override
    public void deleteDependencia(int id) {
        Dependencia existingDependencia = dependenciaRepository.findById(id).orElseThrow();
        dependenciaRepository.delete(existingDependencia);
    }
}
