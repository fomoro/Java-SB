package service;

import java.util.List;
import dto.*;

public interface DetalleSoporteDocumentalService {
    DetalleSoporteDocumentalDTO getDetalleSoporteDocumentalById(int id);
    List<DetalleSoporteDocumentalDTO> getAllDetallesSoporteDocumentales();
    DetalleSoporteDocumentalDTO createDetalleSoporteDocumental(DetalleSoporteDocumentalDTO detalleSoporteDocumentalDTO);
    DetalleSoporteDocumentalDTO updateDetalleSoporteDocumental(int id, DetalleSoporteDocumentalDTO detalleSoporteDocumentalDTO);
    void deleteDetalleSoporteDocumental(int id);
}