package service;

import java.util.List;
import dto.*;

public interface TipoDocumentalService {
    TipoDocumentalDTO getTipoDocumentalById(int id);
    List<TipoDocumentalDTO> getAllTiposDocumentales();
    TipoDocumentalDTO createTipoDocumental(TipoDocumentalDTO tipoDocumentalDTO);
    TipoDocumentalDTO updateTipoDocumental(int id, TipoDocumentalDTO tipoDocumentalDTO);
    void deleteTipoDocumental(int id);
}
