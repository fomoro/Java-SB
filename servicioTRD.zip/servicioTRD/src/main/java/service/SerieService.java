package service;

import java.util.List;
import dto.*;

public interface SerieService {
    SerieDTO getSerieById(int id);
    List<SerieDTO> getAllSeries();
    SerieDTO createSerie(SerieDTO serieDTO);
    SerieDTO updateSerie(int id, SerieDTO serieDTO);
    void deleteSerie(int id);
}