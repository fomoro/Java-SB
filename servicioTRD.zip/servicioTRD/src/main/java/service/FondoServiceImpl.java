package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class FondoServiceImpl implements FondoService {
    private final FondoRepository fondoRepository;

    @Autowired
    public FondoServiceImpl(FondoRepository fondoRepository) {
        this.fondoRepository = fondoRepository;
    }

    @Override
    public FondoDTO getFondoById(int id) {
        Fondo fondo = fondoRepository.findById(id).orElseThrow();
        return Mapper.convertToFondoDTO(fondo);
    }

    @Override
    public List<FondoDTO> getAllFondos() {
        List<Fondo> fondos = fondoRepository.findAll();
        return Mapper.convertToFondoDTOList(fondos);
    }

    @Override
    public FondoDTO createFondo(FondoDTO fondoDTO) {
        Fondo fondo = Mapper.convertToFondo(fondoDTO);
        Fondo savedFondo = fondoRepository.save(fondo);
        return Mapper.convertToFondoDTO(savedFondo);
    }

    @Override
    public FondoDTO updateFondo(int id, FondoDTO fondoDTO) {
        Fondo existingFondo = fondoRepository.findById(id).orElseThrow();         
        //existingFondo.setNombre(fondoDTO.getNombre());
        //existingFondo.setDescription(fondoDTO.getDescription());
        Fondo updatedFondo = fondoRepository.save(existingFondo);
        return Mapper.convertToFondoDTO(updatedFondo);
    }

    @Override
    public void deleteFondo(int id) {
        Fondo existingFondo = fondoRepository.findById(id).orElseThrow();
        fondoRepository.delete(existingFondo);
    }
}