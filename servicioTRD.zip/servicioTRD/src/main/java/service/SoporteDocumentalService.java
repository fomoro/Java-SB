package service;

import java.util.List;
import dto.*;

public interface SoporteDocumentalService {
    SoporteDocumentalDTO getSoporteDocumentalById(int id);
    List<SoporteDocumentalDTO> getAllSoporteDocumentales();
    SoporteDocumentalDTO createSoporteDocumental(SoporteDocumentalDTO soporteDocumentalDTO);
    SoporteDocumentalDTO updateSoporteDocumental(int id, SoporteDocumentalDTO soporteDocumentalDTO);
    void deleteSoporteDocumental(int id);
}