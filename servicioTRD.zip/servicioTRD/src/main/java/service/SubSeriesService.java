package service;

import java.util.List;

import model.*;

public interface SubSeriesService {
	
	boolean agregarSubserie(SubSerie subSerie);

	List<SubSerie> recuperarSubSeries();

	void actualizarSubSerie(SubSerie subSerie);

	boolean eliminarSubserie(Long idSubSerie);

	SubSerie buscarSubserie(Long idSubSerie);
}
