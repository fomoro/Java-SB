package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dao.*;
import dto.*;
import mapper.*;
import model.*;

@Service
public class TipoDeRadicadoServiceImpl implements TipoDeRadicadoService {
    private final TipoDeRadicadoRepository tipoDeRadicadoRepository;

    @Autowired
    public TipoDeRadicadoServiceImpl(TipoDeRadicadoRepository tipoDeRadicadoRepository) {
        this.tipoDeRadicadoRepository = tipoDeRadicadoRepository;
    }

    @Override
    public TipoDeRadicadoDTO getTipoDeRadicadoById(int id) {
        TipoDeRadicado tipoDeRadicado = tipoDeRadicadoRepository.findById(id).orElseThrow();                
        return Mapper.convertToTipoDeRadicadoDTO(tipoDeRadicado);
    }

    @Override
    public List<TipoDeRadicadoDTO> getAllTiposDeRadicado() {
        List<TipoDeRadicado> tiposDeRadicado = tipoDeRadicadoRepository.findAll();
        return Mapper.convertToTipoDeRadicadoDTOList(tiposDeRadicado);
    }

    @Override
    public TipoDeRadicadoDTO createTipoDeRadicado(TipoDeRadicadoDTO tipoDeRadicadoDTO) {
        TipoDeRadicado tipoDeRadicado = Mapper.convertToTipoDeRadicado(tipoDeRadicadoDTO);
        TipoDeRadicado savedTipoDeRadicado = tipoDeRadicadoRepository.save(tipoDeRadicado);
        return Mapper.convertToTipoDeRadicadoDTO(savedTipoDeRadicado);
    }

    @Override
    public TipoDeRadicadoDTO updateTipoDeRadicado(int id, TipoDeRadicadoDTO tipoDeRadicadoDTO) {
        TipoDeRadicado existingTipoDeRadicado = tipoDeRadicadoRepository.findById(id).orElseThrow();                
        //existingTipoDeRadicado.setDescripcion(tipoDeRadicadoDTO.getDescripcion());
        TipoDeRadicado updatedTipoDeRadicado = tipoDeRadicadoRepository.save(existingTipoDeRadicado);
        return Mapper.convertToTipoDeRadicadoDTO(updatedTipoDeRadicado);
    }

    @Override
    public void deleteTipoDeRadicado(int id) {
        TipoDeRadicado existingTipoDeRadicado = tipoDeRadicadoRepository.findById(id).orElseThrow();                
        tipoDeRadicadoRepository.delete(existingTipoDeRadicado);
    }
}
