package service;

import java.util.List;
import dto.*;

public interface TipoDeRadicadoService {
    TipoDeRadicadoDTO getTipoDeRadicadoById(int id);
    List<TipoDeRadicadoDTO> getAllTiposDeRadicado();
    TipoDeRadicadoDTO createTipoDeRadicado(TipoDeRadicadoDTO tipoDeRadicadoDTO);
    TipoDeRadicadoDTO updateTipoDeRadicado(int id, TipoDeRadicadoDTO tipoDeRadicadoDTO);
    void deleteTipoDeRadicado(int id);
}