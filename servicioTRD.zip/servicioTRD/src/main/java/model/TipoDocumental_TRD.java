package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TipoDocumental_TRD")
public class TipoDocumental_TRD {
    @Id
    @ManyToOne
    @JoinColumn(name = "id_tipo_documental")
    private TipoDocumental tipoDocumental;

    @Id
    @ManyToOne
    @JoinColumn(name = "id_trd")
    private TRD trd;

    @ManyToOne
    @JoinColumn(name = "id_detalleSoporteDocumental")
    private DetalleSoporteDocumental detalleSoporteDocumental;
}
