package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Dependencia")
public class Dependencia {
    @Id
    @Column(name = "id_dependencia")
    private int idDependencia;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "sigla")
    private String sigla;

    @Column(name = "estado")
    private int estado;

    @ManyToOne
    @JoinColumn(name = "id_padre")
    private Dependencia padre;

    @ManyToOne
    @JoinColumn(name = "id_fondo")
    private Fondo fondo;
}