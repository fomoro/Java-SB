package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SoporteDocumental")
public class SoporteDocumental {
    @Id
    @Column(name = "id_soporte_Documental")
    private int idSoporteDocumental;

    @Column(name = "descripcion")
    private String descripcion;
}