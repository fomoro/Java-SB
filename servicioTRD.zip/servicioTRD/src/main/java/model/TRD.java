package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TRD")
public class TRD {
    @Id
    @Column(name = "id_trd")
    private int idTrd;

    @ManyToOne
    @JoinColumn(name = "id_serieSubserie")
    private Serie serieSubserie;

    @Column(name = "observacion")
    private String observacion;

    @Column(name = "estado")
    private int estado;

    @ManyToOne
    @JoinColumn(name = "id_dependencia")
    private Dependencia dependencia;
}