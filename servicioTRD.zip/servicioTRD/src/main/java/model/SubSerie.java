package model;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.*;

/**
 * The persistent class for the Subserie database table.
 * 
 */
@Entity
@Table(name="SubSerie")
@NamedQuery(name="Contacto.findAll", query="SELECT c FROM SubSerie c")
public class SubSerie implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSubSerie;
    private String codigoSerie;
    private int codigoSubserie;
    private String descripcion;
    private LocalDate fechaInicial;
    private LocalDate fechaFinal;
    private int tiempoArchivoGestion;
    private int tiempoArchivoCentral;
    private String soporte;
    private String disposicionFinal;
    private String estado;
    private String procedimiento;


    public SubSerie() {
    	//empty for framework
    }
    
    public SubSerie(Long idSubSerie, String codigoSerie, int codigoSubserie, String descripcion, LocalDate fechaInicial,
			LocalDate fechaFinal, int tiempoArchivoGestion, int tiempoArchivoCentral, String soporte,
			String disposicionFinal, String estado, String procedimiento) {
		super();
		this.idSubSerie = idSubSerie;
		this.codigoSerie = codigoSerie;
		this.codigoSubserie = codigoSubserie;
		this.descripcion = descripcion;
		this.fechaInicial = fechaInicial;
		this.fechaFinal = fechaFinal;
		this.tiempoArchivoGestion = tiempoArchivoGestion;
		this.tiempoArchivoCentral = tiempoArchivoCentral;
		this.soporte = soporte;
		this.disposicionFinal = disposicionFinal;
		this.estado = estado;
		this.procedimiento = procedimiento;
	}
    
	// getters y setters    
    public Long getIdSubSerie() {
		return idSubSerie;
	}
	public void setIdSubSerie(Long idSubSerie) {
		this.idSubSerie = idSubSerie;
	}
	public String getCodigoSerie() {
		return codigoSerie;
	}
	public void setCodigoSerie(String codigoSerie) {
		this.codigoSerie = codigoSerie;
	}
	public int getCodigoSubserie() {
		return codigoSubserie;
	}
	public void setCodigoSubserie(int codigoSubserie) {
		this.codigoSubserie = codigoSubserie;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public LocalDate getFechaInicial() {
		return fechaInicial;
	}
	public void setFechaInicial(LocalDate fechaInicial) {
		this.fechaInicial = fechaInicial;
	}
	public LocalDate getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(LocalDate fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	public int getTiempoArchivoGestion() {
		return tiempoArchivoGestion;
	}
	public void setTiempoArchivoGestion(int tiempoArchivoGestion) {
		this.tiempoArchivoGestion = tiempoArchivoGestion;
	}
	public int getTiempoArchivoCentral() {
		return tiempoArchivoCentral;
	}
	public void setTiempoArchivoCentral(int tiempoArchivoCentral) {
		this.tiempoArchivoCentral = tiempoArchivoCentral;
	}
	public String getSoporte() {
		return soporte;
	}
	public void setSoporte(String soporte) {
		this.soporte = soporte;
	}
	public String getDisposicionFinal() {
		return disposicionFinal;
	}
	public void setDisposicionFinal(String disposicionFinal) {
		this.disposicionFinal = disposicionFinal;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getProcedimiento() {
		return procedimiento;
	}
	public void setProcedimiento(String procedimiento) {
		this.procedimiento = procedimiento;
	}    
}
