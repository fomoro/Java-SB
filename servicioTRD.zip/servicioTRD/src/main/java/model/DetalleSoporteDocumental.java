package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "DetalleSoporteDocumental")
public class DetalleSoporteDocumental {
    @Id
    @Column(name = "id_detalle_Soporte_Documental")
    private int idDetalleSoporteDocumental;

    @ManyToOne
    @JoinColumn(name = "id_soporteDocumental")
    private SoporteDocumental soporteDocumental;

    @Column(name = "descripcion")
    private String descripcion;
}