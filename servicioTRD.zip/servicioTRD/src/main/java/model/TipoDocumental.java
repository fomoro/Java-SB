package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TipoDocumental")
public class TipoDocumental {
    @Id
    @Column(name = "id_tipo_documental")
    private int idTipoDocumental;

    @Column(name = "termino_tramite")
    private int terminoTramite;

    @ManyToOne
    @JoinColumn(name = "tipo_de_radicado")
    private TipoDeRadicado tipoDeRadicado;

    @Column(name = "descripcion")
    private String descripcion;
}