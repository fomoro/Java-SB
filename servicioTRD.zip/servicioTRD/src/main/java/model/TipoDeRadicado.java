package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TipoDeRadicado")
public class TipoDeRadicado {
    @Id
    @Column(name = "id_tipo_de_radicado")
    private int idTipoDeRadicado;

    @Column(name = "descripcion")
    private String descripcion;
}