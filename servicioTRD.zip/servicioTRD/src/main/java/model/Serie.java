package model;

import java.util.Date;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Serie")
public class Serie {
    @Id
    @Column(name = "id_serieSubserie")
    private int idSerieSubserie;

    @ManyToOne
    @JoinColumn(name = "id_padre")
    private Serie padre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "fecha_vigencia_inicial")
    private Date fechaVigenciaInicial;

    @Column(name = "fecha_vigencia_final")
    private Date fechaVigenciaFinal;

    @Column(name = "CT")
    private int ct;

    @Column(name = "E")
    private int e;

    @Column(name = "MT")
    private int mt;

    @Column(name = "S")
    private int s;

    @Column(name = "tiempo_archivo_gestion")
    private int tiempoArchivoGestion;

    @Column(name = "tiempo_archivo_central")
    private int tiempoArchivoCentral;

    @Column(name = "observacion")
    private String observacion;
}