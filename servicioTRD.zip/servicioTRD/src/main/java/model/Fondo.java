package model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Fondo")
public class Fondo {
    @Id
    @Column(name = "id_fondo")
    private int idFondo;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "description", nullable = false)
    private String description;	
}