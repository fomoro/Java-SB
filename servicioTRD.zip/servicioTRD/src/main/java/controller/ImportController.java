package controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import dto.*;
import model.*;
import service.*;

@RestController
@RequestMapping("/api/importTRD")
public class ImportController {
	
	@Autowired
	private DataImportService dataImportService;
	
	@PostMapping("/dataJSON")
	public ResponseEntity<String> importData(@RequestBody DataImportRequest request) {
	    String result = dataImportService.importDataJSON(request);
	    return ResponseEntity.ok(result);
	}
	
	@PostMapping("/data")
    public ResponseEntity<String> importData() {
        dataImportService.importDataFromTXT();
        return ResponseEntity.ok("Data imported successfully");
    }
		
}
